import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptainmarvelPage } from './captainmarvel.page';

describe('CaptainmarvelPage', () => {
  let component: CaptainmarvelPage;
  let fixture: ComponentFixture<CaptainmarvelPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaptainmarvelPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptainmarvelPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
