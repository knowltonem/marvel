import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-captainmarvel',
  templateUrl: './captainmarvel.page.html',
  styleUrls: ['./captainmarvel.page.scss'],
})
export class CaptainmarvelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
