import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hulk',
  templateUrl: './hulk.page.html',
  styleUrls: ['./hulk.page.scss'],
})
export class HulkPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
