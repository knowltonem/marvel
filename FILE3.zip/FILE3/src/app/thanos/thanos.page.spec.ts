import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThanosPage } from './thanos.page';

describe('ThanosPage', () => {
  let component: ThanosPage;
  let fixture: ComponentFixture<ThanosPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThanosPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThanosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
