import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thanos',
  templateUrl: './thanos.page.html',
  styleUrls: ['./thanos.page.scss'],
})
export class ThanosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
