import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GalactusPage } from './galactus.page';

describe('GalactusPage', () => {
  let component: GalactusPage;
  let fixture: ComponentFixture<GalactusPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GalactusPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GalactusPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
