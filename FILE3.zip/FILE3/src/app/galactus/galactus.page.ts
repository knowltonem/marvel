import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-galactus',
  templateUrl: './galactus.page.html',
  styleUrls: ['./galactus.page.scss'],
})
export class GalactusPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
