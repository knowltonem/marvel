import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-captain',
  templateUrl: './captain.page.html',
  styleUrls: ['./captain.page.scss'],
})
export class CaptainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
