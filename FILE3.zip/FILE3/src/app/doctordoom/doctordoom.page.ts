import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctordoom',
  templateUrl: './doctordoom.page.html',
  styleUrls: ['./doctordoom.page.scss'],
})
export class DoctordoomPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
