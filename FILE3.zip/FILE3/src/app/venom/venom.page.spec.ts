import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VenomPage } from './venom.page';

describe('VenomPage', () => {
  let component: VenomPage;
  let fixture: ComponentFixture<VenomPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VenomPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VenomPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
