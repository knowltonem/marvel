import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venom',
  templateUrl: './venom.page.html',
  styleUrls: ['./venom.page.scss'],
})
export class VenomPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
