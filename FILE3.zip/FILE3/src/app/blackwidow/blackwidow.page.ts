import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blackwidow',
  templateUrl: './blackwidow.page.html',
  styleUrls: ['./blackwidow.page.scss'],
})
export class BlackwidowPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
