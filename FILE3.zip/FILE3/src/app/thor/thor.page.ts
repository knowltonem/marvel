import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thor',
  templateUrl: './thor.page.html',
  styleUrls: ['./thor.page.scss'],
})
export class ThorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
