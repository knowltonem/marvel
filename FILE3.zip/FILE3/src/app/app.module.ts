import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpModule } from '@angular/http';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireDatabaseModule } from '@angular/fire/database';

import { environment } from '../environments/environment';


var firebaseConfig = {
    apiKey: "AIzaSyC92-w-UBf0NzTjPvdpHbE7cg4p87KDUTs",
    authDomain: "mymav-9e75d.firebaseapp.com",
    databaseURL: "https://mymav-9e75d.firebaseio.com",
    projectId: "mymav-9e75d",
    storageBucket: "mymav-9e75d.appspot.com",
    messagingSenderId: "956215006576",
    appId: "1:956215006576:web:7a55e83214757f61"

  };

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [
  BrowserModule,
  HttpModule,
  IonicModule.forRoot(),
  AppRoutingModule,
  AngularFireDatabaseModule,
  AngularFireModule.initializeApp(firebaseConfig),
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
