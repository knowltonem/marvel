import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ironman',
  templateUrl: './ironman.page.html',
  styleUrls: ['./ironman.page.scss'],
})
export class IronmanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
