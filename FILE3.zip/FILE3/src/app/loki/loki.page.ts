import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loki',
  templateUrl: './loki.page.html',
  styleUrls: ['./loki.page.scss'],
})
export class LokiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
