import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ultron',
  templateUrl: './ultron.page.html',
  styleUrls: ['./ultron.page.scss'],
})
export class UltronPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
