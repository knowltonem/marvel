import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', loadChildren: './tabs/tabs.module#TabsPageModule' },
  { path: 'page2', loadChildren: './page2/page2.module#Page2PageModule' },
  { path: 'contact', loadChildren: './contact/contact.module#ContactPageModule' },
  { path: 'hulk', loadChildren: './hulk/hulk.module#HulkPageModule' },
  { path: 'thor', loadChildren: './thor/thor.module#ThorPageModule' },
  { path: 'ironman', loadChildren: './ironman/ironman.module#IronmanPageModule' },
  { path: 'blackwidow', loadChildren: './blackwidow/blackwidow.module#BlackwidowPageModule' },
  { path: 'captain', loadChildren: './captain/captain.module#CaptainPageModule' },
  { path: 'captainmarvel', loadChildren: './captainmarvel/captainmarvel.module#CaptainmarvelPageModule' },
  { path: 'thanos', loadChildren: './thanos/thanos.module#ThanosPageModule' },
  { path: 'galactus', loadChildren: './galactus/galactus.module#GalactusPageModule' },
  { path: 'venom', loadChildren: './venom/venom.module#VenomPageModule' },
  { path: 'loki', loadChildren: './loki/loki.module#LokiPageModule' },
  { path: 'ultron', loadChildren: './ultron/ultron.module#UltronPageModule' },
  { path: 'doctor', loadChildren: './doctor/doctor.module#DoctorPageModule' },
  { path: 'doctordoom', loadChildren: './doctordoom/doctordoom.module#DoctordoomPageModule' }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
